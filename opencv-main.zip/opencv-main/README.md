# Opencv

### Catching Mouse Click Event using OpenCV
### Creating Shapes using Mouse & OpenCV
### Matplotlib and opencv
### Opencv webcam
